package com.nayemtech;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Book book1 = new Book("Bangla", "Nayem", "2356", 44.5, 10);
        Book book2 = new Book("Bangla2", "Nayem2", "23562", 44.5, 10);
        Customer customer1 = new Customer("Mehedi", "nayem73@gmail.com", "Dhaka");

        List<Book> books = new ArrayList<>();
        books.add(book1);
        books.add(book2);
        Order order1 = new Order(customer1, books, true);
        order1.getBookInfo();

    }
}