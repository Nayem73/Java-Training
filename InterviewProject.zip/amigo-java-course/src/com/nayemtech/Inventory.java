package com.nayemtech;

public class Inventory {

}
