package com.nayemtech;

import java.util.ArrayList;
import java.util.List;

public class Order {
    private Customer customer;
    private List<Book> books = new ArrayList<>();
    private Boolean orderStatus;

    public Order() {
    }

    public Order(Customer customer, List<Book> books, Boolean orderStatus) {
        this.customer = customer;
        this.books = books;
        this.orderStatus = orderStatus;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public List<Book> getBooks() {
        return books;
    }

    public void setBooks(List<Book> books) {
        this.books = books;
    }

    public Boolean getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(Boolean orderStatus) {
        this.orderStatus = orderStatus;
    }

    public void getBookInfo() {
       // System.out.println(this.getCustomer().getName());
        System.out.println(this.getBooks());
    }

    @Override
    public String toString() {
        return "Order{" +
                "customer=" + customer +
                ", books=" + books +
                ", orderStatus=" + orderStatus +
                '}';
    }
}
